__author__ = 'ananyapoddar'


def try_fn(some_val):
    return "I am working", some_val
